(function() {
  Class(File({
    open: function() {
      var data, fp, nsIFilePicker, res, thefile;
      nsIFilePicker = Components.interfaces.nsIFilePicker;
      fp = Components.classes["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
      fp.init(window, "Open File", nsIFilePicker.modeOpen);
      fp.appendFilters(nsIFilePicker.filterText | nsIFilePicker.filterAll);
      res = fp.show();
      if (res === nsIFilePicker.returnOK) {
        thefile = fp.file;
        data = this.read(thefile.path);
        return this.makeTree(data);
      }
    },
    read: function(filename) {
      var file, inputStream, nsIFileInputStream, nsILocalFile, nsIScriptableInputStream, output, sInputStream;
      nsILocalFile = Components.interfaces.nsILocalFile;
      file = Components.classes["@mozilla.org/file/local;1"].createInstance(nsILocalFile);
      file.initWithPath(filename);
      if (file.exists() === false) {
        alert("File does not exist");
      }
      nsIFileInputStream = Components.interfaces.nsIFileInputStream;
      inputStream = Components.classes["@mozilla.org/network/file-input-stream;1"].createInstance(nsIFileInputStream);
      inputStream.init(file, 0x01, 00004, null);
      nsIScriptableInputStream = Components.interfaces.nsIScriptableInputStream;
      sInputStream = Components.classes["@mozilla.org/scriptableinputstream;1"].createInstance(nsIScriptableInputStream);
      sInputStream.init(inputStream);
      output = sInputStream.read(sInputStream.available());
      return output;
    },
    save: function() {
      var fp, nsIFilePicker, res, thefile;
      nsIFilePicker = Components.interfaces.nsIFilePicker;
      fp = Components.classes["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
      fp.init(window, "Save File", nsIFilePicker.modeSave);
      fp.appendFilters(nsIFilePicker.filterText | nsIFilePicker.filterAll);
      res = fp.show();
      if (res === nsIFilePicker.returnOK) {
        thefile = fp.file;
        return this.write(thefile.path, this.xml2string(this.doc));
      }
    },
    write: function(filename, data) {
      var file, nsIFileOutputStream, nsILocalFile, outputStream;
      nsILocalFile = Components.interfaces.nsILocalFile;
      file = Components.classes["@mozilla.org/file/local;1"].createInstance(nsILocalFile);
      nsIFileOutputStream = Components.interfaces.nsIFileOutputStream;
      outputStream = Components.classes["@mozilla.org/network/file-output-stream;1"].createInstance(nsIFileOutputStream);
      file.initWithPath(filename);
      outputStream.init(file, 0x04 | 0x08 | 0x20, 0666, 0);
      outputStream.write(data, data.length);
      return outputStream.close();
    },
    makeTree: function(data) {
      var doc, parser, tree;
      parser = new DOMParser();
      doc = parser.parseFromString(data, "application/xml");
      tree = d3.select("box").append("tree").attr("flex", "1").attr("hidecolumnpicker", "true").attr("onselect", "file.show(this)");
      tree.append("treecols").append("treecol").attr("label", "label").attr("flex", 1).attr("primary", "true");
      this.counter = 0;
      if (doc.childNodes !== null) {
        return this.itemsToTreeDOM(doc.childNodes, tree);
      }
    },
    itemsToTreeDOM: function(items, node) {
      var elem, elements, treechildren, _i, _len, _results;
      elements = this.getElements(items);
      if (elements.length > 0) {
        treechildren = node.append("treechildren");
        _results = [];
        for (_i = 0, _len = elements.length; _i < _len; _i++) {
          elem = elements[_i];
          _results.push(this.elemToTreeDOM(elem, treechildren));
        }
        return _results;
      }
    },
    elemToTreeDOM: function(elem, children) {
      var treeitem, treerow;
      treeitem = children.append("treeitem");
      treeitem.attr("container", "true").attr("open", "true").attr("id", this.counter);
      elem.setAttribute('id', this.counter++);
      treerow = treeitem.append("treerow");
      treerow.append("treecell").attr("label", elem.nodeName);
      return this.itemsToTreeDOM(elem.childNodes, treeitem);
    },
    getElements: function(items) {
      var child, elements, i, _ref;
      elements = new Array();
      if (items.length > 0) {
        for (i = 0, _ref = items.length - 1; 0 <= _ref ? i <= _ref : i >= _ref; 0 <= _ref ? i++ : i--) {
          child = items.item(i);
          if (child.nodeType === 1) {
            elements.push(child);
          }
        }
      }
      return elements;
    },
    xml2string: function(node) {
      var serializer;
      serializer = new XMLSerializer();
      return serializer.serializeToString(node);
    },
    show: function(tree) {
      var item;
      item = tree.view.getItemAtIndex(tree.currentIndex);
      this.current = item.id;
      return alert("show:" + item.id);
    }
  }));
  this.file = new File;
}).call(this);
